import time
import json
import hmac
import hashlib
import requests
import os
from datetime import datetime, timedelta

from database import get_connection


SECRET = os.getenv("WEBHOOK_SECRET", "my-webhook-secret")

# Maximum total attempts:
# 1 initial attempt + 3 retries = 4 attempts
MAX_ATTEMPTS = 4

# Retry delays:
# After attempt 1 -> 30 seconds
# After attempt 2 -> 5 minutes
# After attempt 3 -> 30 minutes
RETRY_DELAYS = [
    30,
    300,
    1800
]


def generate_signature(payload):
    return hmac.new(
        SECRET.encode(),
        payload.encode(),
        hashlib.sha256
    ).hexdigest()


def deliver_event(event):
    payload_json = json.dumps(event["payload"])

    signature = generate_signature(payload_json)

    headers = {
        "Content-Type": "application/json",
        "X-Webhook-Signature": signature
    }

    try:
        response = requests.post(
            event["webhook_url"],
            data=payload_json,
            headers=headers,
            timeout=10
        )

        return response.status_code

    except Exception:
        return None


def get_pending_events():
    connection = get_connection()

    rows = connection.execute(
        """
        SELECT id, event_type, payload, webhook_url,
               next_retry_at, retry_count
        FROM events
        WHERE status = 'pending'
          AND (
              next_retry_at IS NULL
              OR next_retry_at <= datetime('now')
          )
        ORDER BY id
        """
    ).fetchall()

    connection.close()

    events = []

    for row in rows:
        events.append({
            "id": row["id"],
            "event_type": row["event_type"],
            "payload": json.loads(row["payload"]),
            "webhook_url": row["webhook_url"],
            "next_retry_at": row["next_retry_at"],
            "retry_count": row["retry_count"]
        })

    return events


def record_attempt(event_id, status_code, outcome):
    connection = get_connection()

    connection.execute(
        """
        INSERT INTO attempts (
            event_id,
            attempted_at,
            http_status,
            outcome
        )
        VALUES (?, datetime('now'), ?, ?)
        """,
        (event_id, status_code, outcome)
    )

    connection.commit()
    connection.close()


def mark_delivered(event_id):
    connection = get_connection()

    connection.execute(
        """
        UPDATE events
        SET status = 'delivered',
            next_retry_at = NULL
        WHERE id = ?
        """,
        (event_id,)
    )

    connection.commit()
    connection.close()


def mark_dead(event_id):
    connection = get_connection()

    connection.execute(
        """
        UPDATE events
        SET status = 'dead',
            next_retry_at = NULL
        WHERE id = ?
        """,
        (event_id,)
    )

    connection.commit()
    connection.close()


def schedule_retry(event_id, retry_count, delay_seconds):
    next_retry_at = (
        datetime.utcnow() + timedelta(seconds=delay_seconds)
    ).strftime("%Y-%m-%d %H:%M:%S")

    connection = get_connection()

    connection.execute(
        """
        UPDATE events
        SET retry_count = ?,
            next_retry_at = ?
        WHERE id = ?
        """,
        (
            retry_count,
            next_retry_at,
            event_id
        )
    )

    connection.commit()
    connection.close()

    return next_retry_at


while True:

    events = get_pending_events()

    for event in events:

        # retry_count represents how many retries have already
        # been scheduled/performed in the current delivery cycle.
        retry_count = event["retry_count"]

        # Current attempt number:
        # retry_count 0 -> attempt 1
        # retry_count 1 -> attempt 2
        # retry_count 2 -> attempt 3
        # retry_count 3 -> attempt 4
        attempt_number = retry_count + 1

        status_code = deliver_event(event)

        # SUCCESS
        if status_code is not None and 200 <= status_code < 300:

            record_attempt(
                event["id"],
                status_code,
                "success"
            )

            mark_delivered(event["id"])

            print(
                f"Event {event['id']} delivered successfully "
                f"with status: {status_code}"
            )

        # FAILURE
        else:

            record_attempt(
                event["id"],
                status_code,
                "failed"
            )

            # Four total attempts reached
            if attempt_number >= MAX_ATTEMPTS:

                mark_dead(event["id"])

                print(
                    f"Event {event['id']} is dead "
                    f"after {MAX_ATTEMPTS} attempts"
                )

            else:

                # retry_count 0 -> 30 sec
                # retry_count 1 -> 5 min
                # retry_count 2 -> 30 min
                delay = RETRY_DELAYS[retry_count]

                new_retry_count = retry_count + 1

                next_retry_at = schedule_retry(
                    event["id"],
                    new_retry_count,
                    delay
                )

                print(
                    f"Event {event['id']} delivery failed "
                    f"(attempt {attempt_number}/{MAX_ATTEMPTS}). "
                    f"Next retry at {next_retry_at}"
                )

    time.sleep(2)