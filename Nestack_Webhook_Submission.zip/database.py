import sqlite3


DATABASE_NAME = "webhook.db"


def get_connection():
    connection = sqlite3.connect(DATABASE_NAME)
    connection.row_factory = sqlite3.Row
    return connection


def initialize_database():
    connection = get_connection()

    # Events table
    connection.execute("""
        CREATE TABLE IF NOT EXISTS events (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_type TEXT NOT NULL,
            payload TEXT NOT NULL,
            webhook_url TEXT NOT NULL,
            status TEXT NOT NULL DEFAULT 'pending',
            created_at TEXT NOT NULL,
            next_retry_at TEXT,
            retry_count INTEGER NOT NULL DEFAULT 0
        )
    """)

    # Add retry_count to an existing database if the column
    # does not already exist.
    try:
        connection.execute("""
            ALTER TABLE events
            ADD COLUMN retry_count INTEGER NOT NULL DEFAULT 0
        """)
    except sqlite3.OperationalError:
        pass

    # Attempts table
    connection.execute("""
        CREATE TABLE IF NOT EXISTS attempts (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            event_id INTEGER NOT NULL,
            attempted_at TEXT NOT NULL,
            http_status INTEGER,
            outcome TEXT NOT NULL,
            FOREIGN KEY (event_id) REFERENCES events(id)
        )
    """)

    connection.commit()
    connection.close()


if __name__ == "__main__":
    initialize_database()
    print("Database initialized successfully!")