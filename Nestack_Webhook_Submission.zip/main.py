from fastapi import FastAPI, HTTPException
from pydantic import BaseModel, Field
from database import initialize_database, get_connection
from datetime import datetime
import json


class EventCreate(BaseModel):
    event_type: str = Field(alias="type")
    payload: dict
    webhook_url: str

    class Config:
        populate_by_name = True


app = FastAPI(title="Webhook Delivery Engine")


@app.on_event("startup")
def startup():
    initialize_database()


@app.get("/")
def root():
    return {
        "message": "Webhook Delivery Engine is running"
    }


@app.post("/events", status_code=201)
def create_event(event: EventCreate):
    connection = get_connection()

    created_at = datetime.utcnow().isoformat()

    cursor = connection.execute(
        """
        INSERT INTO events (
            event_type,
            payload,
            webhook_url,
            status,
            created_at
        )
        VALUES (?, ?, ?, ?, ?)
        """,
        (
            event.event_type,
            json.dumps(event.payload),
            event.webhook_url,
            "pending",
            created_at
        )
    )

    connection.commit()

    event_id = cursor.lastrowid

    connection.close()

    return {
        "id": event_id,
        "type": event.event_type,
        "payload": event.payload,
        "webhook_url": event.webhook_url,
        "status": "pending",
        "created_at": created_at,
        "attempts": []
    }


@app.get("/events")
def get_events():
    connection = get_connection()

    rows = connection.execute(
        """
        SELECT id, event_type, payload, webhook_url,
               status, created_at
        FROM events
        ORDER BY id
        """
    ).fetchall()

    events = []

    for row in rows:

        attempt_rows = connection.execute(
            """
            SELECT attempted_at, http_status, outcome
            FROM attempts
            WHERE event_id = ?
            ORDER BY id
            """,
            (row["id"],)
        ).fetchall()

        attempts = []

        for attempt in attempt_rows:
            attempts.append({
                "attempted_at": attempt["attempted_at"],
                "http_status": attempt["http_status"],
                "outcome": attempt["outcome"]
            })

        events.append({
            "id": row["id"],
            "type": row["event_type"],
            "payload": json.loads(row["payload"]),
            "webhook_url": row["webhook_url"],
            "status": row["status"],
            "created_at": row["created_at"],
            "attempts": attempts
        })

    connection.close()

    return events


@app.get("/events/{event_id}")
def get_event(event_id: int):
    connection = get_connection()

    row = connection.execute(
        """
        SELECT id, event_type, payload, webhook_url,
               status, created_at
        FROM events
        WHERE id = ?
        """,
        (event_id,)
    ).fetchone()

    if row is None:
        connection.close()
        raise HTTPException(
            status_code=404,
            detail="Event not found"
        )

    attempts = connection.execute(
        """
        SELECT attempted_at, http_status, outcome
        FROM attempts
        WHERE event_id = ?
        ORDER BY id
        """,
        (event_id,)
    ).fetchall()

    connection.close()

    return {
        "id": row["id"],
        "type": row["event_type"],
        "payload": json.loads(row["payload"]),
        "webhook_url": row["webhook_url"],
        "status": row["status"],
        "created_at": row["created_at"],
        "attempts": [
            {
                "attempted_at": attempt["attempted_at"],
                "http_status": attempt["http_status"],
                "outcome": attempt["outcome"]
            }
            for attempt in attempts
        ]
    }


@app.post("/events/{event_id}/retry")
def retry_event(event_id: int):
    connection = get_connection()

    row = connection.execute(
        """
        SELECT id, status
        FROM events
        WHERE id = ?
        """,
        (event_id,)
    ).fetchone()

    if row is None:
        connection.close()
        raise HTTPException(
            status_code=404,
            detail="Event not found"
        )

    # Manual retry is allowed only for dead events
    if row["status"] != "dead":
        connection.close()
        raise HTTPException(
            status_code=400,
            detail="Only dead events can be retried"
        )

    connection.execute(
        """
        UPDATE events
        SET status = 'pending',
            next_retry_at = NULL,
            retry_count = 0
        WHERE id = ?
        """,
        (event_id,)
    )

    connection.commit()
    connection.close()

    return {
        "message": "Event queued for retry",
        "id": event_id,
        "status": "pending"
    }