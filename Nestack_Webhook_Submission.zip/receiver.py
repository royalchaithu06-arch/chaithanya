from fastapi import FastAPI, Request, HTTPException
import hmac
import hashlib
import os

app = FastAPI()

SECRET = os.getenv("WEBHOOK_SECRET", "my-webhook-secret")


@app.post("/webhook")
async def receive_webhook(request: Request):

    body = await request.body()

    received_signature = request.headers.get("X-Webhook-Signature")

    expected_signature = hmac.new(
        SECRET.encode(),
        body,
        hashlib.sha256
    ).hexdigest()

    if not received_signature or not hmac.compare_digest(
        received_signature,
        expected_signature
    ):
        raise HTTPException(
            status_code=401,
            detail="Invalid webhook signature"
        )

    data = await request.json()

    print("Webhook received!")
    print("Payload:", data)

    return {
        "message": "Webhook received successfully"
    }