# Webhook Delivery Engine

## Live Deployment

https://webhook-delivery-engine-gjtd.onrender.com

A FastAPI-based webhook delivery engine that accepts events, delivers them to webhook endpoints, records delivery attempts, verifies HMAC signatures, and automatically retries failed deliveries.

## Features

- Create webhook events
- Background webhook delivery worker
- Immediate first delivery attempt
- Automatic retry mechanism
- Retry schedule:
  - 30 seconds
  - 5 minutes
  - 30 minutes
- Maximum 4 total delivery attempts
- Events are marked as `dead` after all attempts fail
- Delivery attempt history stored in SQLite
- HMAC-SHA256 webhook signatures
- Manual retry for dead events
- REST API for viewing events and attempts

## Tech Stack

- Python
- FastAPI
- SQLite
- Requests
- Pydantic
- HMAC-SHA256

## Project Structure

```text
backend/
│
├── main.py
├── worker.py
├── receiver.py
├── database.py
├── requirements.txt
├── README.md
└── webhook.db